from setuptools import setup, find_packages
import os

# README'yi oku
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='discord-token-checker',
    version='2.0.0',
    author='Your Name',
    author_email='your.email@example.com',
    description='Gelişmiş Discord Token Kontrol ve Analiz Aracı',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/discord-token-checker',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
    install_requires=[
        'requests>=2.28.0',
        'colorama>=0.4.6',
    ],
    entry_points={
        'console_scripts': [
            'dtc=checker.main:main',
            'discord-token-checker=checker.main:main',
        ],
    },
)