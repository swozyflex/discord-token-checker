#!/usr/bin/env python3
"""
Discord Token Checker v2.0
Gelişmiş Discord Token Kontrol ve Analiz Aracı
"""

import sys
from checker.main import main

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[!] Program kullanıcı tarafından durduruldu.")
        sys.exit(0)
    except Exception as e:
        print(f"\n[!] Beklenmeyen hata: {e}")
        sys.exit(1)