import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import threading
import queue
import time
from .checker import DiscordTokenChecker
from .utils import Colors, Utils

class TokenCheckerGUI:
    """Tkinter GUI Arayüzü"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Discord Token Checker v2.0")
        self.root.geometry("900x700")
        self.root.configure(bg='#2b2b2b')

        self.checker = None
        self.is_checking = False
        self.output_queue = queue.Queue()

        self.setup_ui()
        self.update_output()

    def setup_ui(self):
        """Arayüzü oluştur"""
        # Style
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TLabel', background='#2b2b2b', foreground='white')
        style.configure('TButton', background='#404040', foreground='white')
        style.configure('TFrame', background='#2b2b2b')

        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Title
        title_label = ttk.Label(
            main_frame,
            text="DISCORD TOKEN CHECKER v2.0",
            font=('Arial', 16, 'bold')
        )
        title_label.grid(row=0, column=0, columnspan=3, pady=10)

        # Settings frame
        settings_frame = ttk.LabelFrame(main_frame, text="Ayarlar", padding="10")
        settings_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)

        # Thread count
        ttk.Label(settings_frame, text="Thread Sayısı:").grid(row=0, column=0, sticky=tk.W)
        self.thread_var = tk.StringVar(value="50")
        thread_entry = ttk.Entry(settings_frame, textvariable=self.thread_var, width=10)
        thread_entry.grid(row=0, column=1, sticky=tk.W, padx=5)

        # Timeout
        ttk.Label(settings_frame, text="Timeout (sn):").grid(row=0, column=2, sticky=tk.W, padx=10)
        self.timeout_var = tk.StringVar(value="10")
        timeout_entry = ttk.Entry(settings_frame, textvariable=self.timeout_var, width=10)
        timeout_entry.grid(row=0, column=3, sticky=tk.W, padx=5)

        # Proxy checkbox
        self.proxy_var = tk.BooleanVar(value=False)
        proxy_check = ttk.Checkbutton(
            settings_frame,
            text="Proxy Kullan",
            variable=self.proxy_var
        )
        proxy_check.grid(row=0, column=4, sticky=tk.W, padx=10)

        # Token input
        ttk.Label(main_frame, text="Token Listesi:").grid(row=2, column=0, sticky=tk.W, pady=5)

        self.token_text = scrolledtext.ScrolledText(
            main_frame,
            width=80,
            height=10,
            bg='#1e1e1e',
            fg='white',
            insertbackground='white'
        )
        self.token_text.grid(row=3, column=0, columnspan=3, pady=5)

        # Buttons frame
        buttons_frame = ttk.Frame(main_frame)
        buttons_frame.grid(row=4, column=0, columnspan=3, pady=10)

        # Load file button
        load_btn = ttk.Button(
            buttons_frame,
            text="Dosyadan Yükle",
            command=self.load_tokens_from_file
        )
        load_btn.grid(row=0, column=0, padx=5)

        # Start button
        self.start_btn = ttk.Button(
            buttons_frame,
            text="Kontrolü Başlat",
            command=self.start_checking
        )
        self.start_btn.grid(row=0, column=1, padx=5)

        # Stop button
        self.stop_btn = ttk.Button(
            buttons_frame,
            text="Durdur",
            command=self.stop_checking,
            state='disabled'
        )
        self.stop_btn.grid(row=0, column=2, padx=5)

        # Save button
        self.save_btn = ttk.Button(
            buttons_frame,
            text="Sonuçları Kaydet",
            command=self.save_results
        )
        self.save_btn.grid(row=0, column=3, padx=5)

        # Progress
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            main_frame,
            variable=self.progress_var,
            maximum=100
        )
        self.progress_bar.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)

        # Stats
        stats_frame = ttk.LabelFrame(main_frame, text="İstatistikler", padding="10")
        stats_frame.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)

        self.stats_labels = {}
        stats_text = ['Toplam', 'Geçerli', 'Geçersiz', 'Kilitli', 'Nitro', 'Süre']

        for i, text in enumerate(stats_text):
            ttk.Label(stats_frame, text=f"{text}:").grid(row=0, column=i*2, padx=5)
            self.stats_labels[text] = ttk.Label(stats_frame, text="0", font=('Arial', 10, 'bold'))
            self.stats_labels[text].grid(row=0, column=i*2+1, padx=5)

        # Output
        ttk.Label(main_frame, text="Çıktı:").grid(row=7, column=0, sticky=tk.W, pady=5)

        self.output_text = scrolledtext.ScrolledText(
            main_frame,
            width=80,
            height=12,
            bg='#1e1e1e',
            fg='#00ff00',
            insertbackground='white'
        )
        self.output_text.grid(row=8, column=0, columnspan=3, pady=5)

    def load_tokens_from_file(self):
        """Dosyadan token yükle"""
        filename = filedialog.askopenfilename(
            title="Token dosyası seç",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )

        if filename:
            tokens = Utils.load_tokens(filename)
            self.token_text.delete('1.0', tk.END)
            self.token_text.insert('1.0', '\n'.join(tokens))
            self.log_message(f"{len(tokens)} token yüklendi")

    def start_checking(self):
        """Kontrolü başlat"""
        tokens_text = self.token_text.get('1.0', tk.END).strip()
        if not tokens_text:
            messagebox.showwarning("Uyarı", "Lütfen token girin!")
            return

        tokens = [t.strip() for t in tokens_text.split('\n') if t.strip()]

        self.is_checking = True
        self.start_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        self.progress_var.set(0)

        self.checker_thread = threading.Thread(
            target=self.run_checker,
            args=(tokens,)
        )
        self.checker_thread.start()

    def run_checker(self, tokens):
        """Checker'ı çalıştır"""
        try:
            thread_count = int(self.thread_var.get())
            timeout = int(self.timeout_var.get())
        except:
            thread_count = 50
            timeout = 10

        self.checker = DiscordTokenChecker(
            max_threads=thread_count,
            timeout=timeout,
            use_proxy=self.proxy_var.get()
        )

        def progress_callback(current, total, result):
            progress = (current / total) * 100
            self.output_queue.put(('progress', progress))

            if result.get('valid'):
                self.output_queue.put(('log', f"✓ {result.get('username')} - {result.get('nitro', {}).get('type')}"))

        results = self.checker.check_tokens_bulk(tokens, callback=progress_callback)

        self.output_queue.put(('done', results))

    def stop_checking(self):
        """Kontrolü durdur"""
        self.is_checking = False
        self.log_message("\n⚠ Durduruluyor...")

    def save_results(self):
        """Sonuçları kaydet"""
        if self.checker and (self.checker.valid_tokens or self.checker.invalid_tokens):
            saved_files = self.checker.save_all_results()
            message = "Kaydedilen dosyalar:\n"
            for name, filename in saved_files:
                message += f"{name}: {filename}\n"
            messagebox.showinfo("Başarılı", message)
        else:
            messagebox.showwarning("Uyarı", "Kaydedilecek sonuç yok!")

    def log_message(self, message):
        """Log mesajı ekle"""
        self.output_queue.put(('log', message))

    def update_output(self):
        """Çıktıyı güncelle"""
        try:
            while True:
                msg_type, data = self.output_queue.get_nowait()

                if msg_type == 'progress':
                    self.progress_var.set(data)

                elif msg_type == 'log':
                    self.output_text.insert(tk.END, f"{data}\n")
                    self.output_text.see(tk.END)

                elif msg_type == 'done':
                    stats = data
                    self.stats_labels['Toplam'].config(text=str(stats['total']))
                    self.stats_labels['Geçerli'].config(text=str(stats['valid']))
                    self.stats_labels['Geçersiz'].config(text=str(stats['invalid']))
                    self.stats_labels['Kilitli'].config(text=str(stats['locked']))
                    self.stats_labels['Nitro'].config(text=str(stats['nitro']))
                    self.stats_labels['Süre'].config(text=f"{stats['elapsed']:.1f}s")

                    self.log_message(f"\n✓ Kontrol tamamlandı!")
                    self.log_message(f"Geçerli: {stats['valid']} | Geçersiz: {stats['invalid']}")
                    self.log_message(f"Nitro: {stats['nitro']} | CPM: {stats['cpm']:.0f}")

                    self.start_btn.config(state='normal')
                    self.stop_btn.config(state='disabled')
                    self.progress_var.set(100)

        except queue.Empty:
            pass

        self.root.after(100, self.update_output)

    def run(self):
        """GUI'yi başlat"""
        self.root.mainloop()