import requests
import threading
import queue
import time
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from .utils import Colors, Utils

class DiscordTokenChecker:
    """Discord Token Kontrol Sınıfı"""

    def __init__(self, max_threads=50, timeout=10, use_proxy=False, proxy_file=None):
        self.valid_tokens = []
        self.invalid_tokens = []
        self.locked_tokens = []
        self.unverified_tokens = []
        self.nitro_tokens = []

        self.max_threads = max_threads
        self.timeout = timeout
        self.use_proxy = use_proxy
        self.proxies = []
        self.lock = threading.Lock()
        self.stats = {
            'total': 0,
            'valid': 0,
            'invalid': 0,
            'locked': 0,
            'unverified': 0,
            'nitro': 0,
            'start_time': 0,
            'end_time': 0
        }

        if use_proxy and proxy_file:
            self.load_proxies(proxy_file)

    def load_proxies(self, proxy_file):
        """Proxy listesini yükle"""
        try:
            with open(proxy_file, 'r') as f:
                for line in f:
                    self.proxies.append(line.strip())
        except:
            pass

    def get_proxy(self):
        """Rastgele proxy döndür"""
        if self.proxies:
            import random
            proxy = random.choice(self.proxies)
            return {'http': proxy, 'https': proxy}
        return None

    def check_token_details(self, token):
        """Token detaylarını kontrol et"""
        headers = {
            'Authorization': token.strip(),
            'User-Agent': Utils.random_user_agent(),
            'Content-Type': 'application/json'
        }

        proxies = self.get_proxy() if self.use_proxy else None
        result = {'token': token, 'valid': False}

        try:
            # Kullanıcı bilgisi
            response = requests.get(
                'https://discord.com/api/v10/users/@me',
                headers=headers,
                proxies=proxies,
                timeout=self.timeout
            )

            if response.status_code == 200:
                user = response.json()
                result['valid'] = True
                result['user'] = user
                result['username'] = f"{user.get('username')}#{user.get('discriminator', '0')}"
                result['user_id'] = user.get('id')
                result['email'] = user.get('email', 'Gizli')
                result['phone'] = user.get('phone', 'Yok')
                result['verified'] = user.get('verified', False)
                result['mfa'] = user.get('mfa_enabled', False)
                result['locale'] = user.get('locale', 'Bilinmeyen')
                result['flags'] = user.get('flags', 0)
                result['premium_type'] = user.get('premium_type', 0)
                result['created_at'] = self.snowflake_to_date(user.get('id'))

                # Nitro durumu
                result['nitro'] = self.check_nitro(token, headers, proxies)

                # Avatar URL
                avatar_hash = user.get('avatar')
                if avatar_hash:
                    result['avatar_url'] = f"https://cdn.discordapp.com/avatars/{user['id']}/{avatar_hash}.png"
                else:
                    result['avatar_url'] = "Yok"

                # Banner URL
                banner_hash = user.get('banner')
                if banner_hash:
                    result['banner_url'] = f"https://cdn.discordapp.com/banners/{user['id']}/{banner_hash}.png"

            elif response.status_code == 401:
                result['error'] = 'Geçersiz Token'
            elif response.status_code == 403:
                result['error'] = 'Token Kilitlenmiş'
            elif response.status_code == 429:
                result['error'] = 'Rate Limited - Beklenmeli'
                time.sleep(2)

        except requests.exceptions.Timeout:
            result['error'] = 'Zaman Aşımı'
        except requests.exceptions.ConnectionError:
            result['error'] = 'Bağlantı Hatası'
        except Exception as e:
            result['error'] = str(e)[:50]

        return result

    def check_nitro(self, token, headers, proxies=None):
        """Nitro aboneliğini kontrol et"""
        try:
            # Premium type kontrolü
            profile_response = requests.get(
                'https://discord.com/api/v10/users/@me/profile',
                headers=headers,
                proxies=proxies,
                timeout=5
            )

            # Billing kontrolü
            billing_response = requests.get(
                'https://discord.com/api/v10/users/@me/billing/subscriptions',
                headers=headers,
                proxies=proxies,
                timeout=5
            )

            nitro_info = {
                'has_nitro': False,
                'type': 'Nitro Yok',
                'since': None,
                'giftable': False
            }

            if profile_response.status_code == 200:
                profile = profile_response.json()
                premium_type = profile.get('premium_type', 0)
                if premium_type == 1:
                    nitro_info['has_nitro'] = True
                    nitro_info['type'] = 'Nitro Classic'
                elif premium_type == 2:
                    nitro_info['has_nitro'] = True
                    nitro_info['type'] = 'Nitro Full'
                elif premium_type == 3:
                    nitro_info['has_nitro'] = True
                    nitro_info['type'] = 'Nitro Basic'

            if billing_response.status_code == 200:
                subscriptions = billing_response.json()
                for sub in subscriptions:
                    if sub.get('status') == 1:  # Aktif
                        nitro_info['has_nitro'] = True
                        nitro_info['type'] = sub.get('name', 'Nitro')
                        if 'current_period_end' in sub:
                            nitro_info['since'] = sub['current_period_end']

            return nitro_info

        except:
            return {'has_nitro': False, 'type': 'Kontrol Edilemedi'}

    def snowflake_to_date(self, snowflake):
        """Snowflake ID'yi tarihe çevir"""
        try:
            timestamp = ((int(snowflake) >> 22) + 1420070400000) / 1000
            from datetime import datetime
            return datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
        except:
            return "Bilinmeyen"

    def check_tokens_bulk(self, tokens, callback=None):
        """Toplu token kontrolü"""
        self.stats['total'] = len(tokens)
        self.stats['start_time'] = time.time()

        print(f"\n{Colors.CYAN}[BİLGİ] {len(tokens)} token kontrol edilecek...")
        print(f"{Colors.CYAN}[BİLGİ] Thread sayısı: {self.max_threads}")
        print(f"{Colors.CYAN}[BİLGİ] Timeout: {self.timeout}s\n")

        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = {executor.submit(self.check_token_details, token): token for token in tokens}

            completed = 0
            for future in as_completed(futures):
                completed += 1
                result = future.result()

                with self.lock:
                    if result.get('valid'):
                        self.valid_tokens.append(result)
                        self.stats['valid'] += 1

                        nitro_status = result.get('nitro', {}).get('type', 'Nitro Yok')
                        if result.get('nitro', {}).get('has_nitro'):
                            self.nitro_tokens.append(result)
                            self.stats['nitro'] += 1

                        if not result.get('verified'):
                            self.unverified_tokens.append(result)
                            self.stats['unverified'] += 1

                        print(f"{Colors.GREEN}[GEÇERLİ] {result['token'][:30]}... | "
                              f"{result['username']} | {nitro_status} | Email: {result['email']}")

                    elif result.get('error') == 'Token Kilitlenmiş':
                        self.locked_tokens.append(result['token'])
                        self.stats['locked'] += 1
                        print(f"{Colors.YELLOW}[KİLİTLİ] {result['token'][:30]}...")

                    else:
                        self.invalid_tokens.append(result['token'])
                        self.stats['invalid'] += 1
                        if completed % 10 == 0:
                            print(f"{Colors.RED}[GEÇERSİZ] {result['token'][:30]}... - {result.get('error', 'Bilinmeyen')}")

                # Progress bar
                if completed % 5 == 0 or completed == len(tokens):
                    Utils.print_progress_bar(
                        completed, len(tokens),
                        prefix=f'{Colors.BLUE}İlerleme:{Colors.RESET}',
                        suffix=f'{Colors.WHITE}{completed}/{len(tokens)}{Colors.RESET}'
                    )

                if callback:
                    callback(completed, len(tokens), result)

                time.sleep(0.1)  # Rate limiting

        self.stats['end_time'] = time.time()
        return self.get_stats()

    def get_stats(self):
        """İstatistikleri döndür"""
        elapsed = self.stats['end_time'] - self.stats['start_time']
        cpm = len(self.valid_tokens + self.invalid_tokens) / (elapsed / 60) if elapsed > 0 else 0

        return {
            **self.stats,
            'elapsed': elapsed,
            'cpm': cpm,
            'valid_rate': f"{(self.stats['valid']/self.stats['total']*100):.1f}%" if self.stats['total'] > 0 else "0%"
        }

    def save_all_results(self):
        """Tüm sonuçları kaydet"""
        saved_files = []

        # Geçerli token'ları kaydet
        if self.valid_tokens:
            filename = Utils.save_results('valid_tokens', self.valid_tokens, 'json')
            saved_files.append(('Geçerli Tokenlar', filename))

            # Sadece token'ları txt olarak
            token_only = [t['token'] for t in self.valid_tokens]
            filename = Utils.save_results('valid_tokens_only', token_only, 'txt')
            saved_files.append(('Sadece Tokenlar', filename))

        # Nitro token'ları
        if self.nitro_tokens:
            filename = Utils.save_results('nitro_tokens', self.nitro_tokens, 'json')
            saved_files.append(('Nitro Tokenlar', filename))

        # Geçersiz token'lar
        if self.invalid_tokens:
            filename = Utils.save_results('invalid_tokens', self.invalid_tokens, 'txt')
            saved_files.append(('Geçersiz Tokenlar', filename))

        # Detaylı rapor
        report = {
            'stats': self.stats,
            'valid_count': len(self.valid_tokens),
            'invalid_count': len(self.invalid_tokens),
            'locked_count': len(self.locked_tokens),
            'unverified_count': len(self.unverified_tokens),
            'nitro_count': len(self.nitro_tokens),
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        filename = Utils.save_results('report', report, 'json')
        saved_files.append(('Rapor', filename))

        return saved_files