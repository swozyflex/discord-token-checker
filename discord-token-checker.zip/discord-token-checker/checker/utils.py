import os
import sys
import json
import time
import random
from datetime import datetime
from colorama import Fore, Style, init
import ctypes

init(autoreset=True)

class Colors:
    """Renk sabitleri"""
    GREEN = Fore.GREEN
    RED = Fore.RED
    YELLOW = Fore.YELLOW
    CYAN = Fore.CYAN
    MAGENTA = Fore.MAGENTA
    BLUE = Fore.BLUE
    WHITE = Fore.WHITE
    RESET = Style.RESET_ALL
    BOLD = Style.BRIGHT

class Utils:
    """Yardımcı fonksiyonlar"""

    @staticmethod
    def clear_screen():
        """Ekranı temizle"""
        os.system('cls' if os.name == 'nt' else 'clear')

    @staticmethod
    def print_banner():
        """Banner yazdır"""
        banner = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════╗
║     DISCORD TOKEN CHECKER v2.0                    ║
║     Gelişmiş Kontrol ve Analiz Aracı              ║
║     GitHub: github.com/yourusername/dtc           ║
╚══════════════════════════════════════════════════╝{Colors.RESET}
        """
        print(banner)

    @staticmethod
    def print_progress_bar(iteration, total, prefix='', suffix='', length=50):
        """Progress bar göster"""
        percent = f"{100 * (iteration / float(total)):.1f}"
        filled = int(length * iteration // total)
        bar = '█' * filled + '░' * (length - filled)

        sys.stdout.write(f'\r{prefix} |{Colors.CYAN}{bar}{Colors.RESET}| {percent}% {suffix}')
        sys.stdout.flush()

        if iteration == total:
            print()

    @staticmethod
    def load_tokens(file_path):
        """Token'ları dosyadan yükle"""
        tokens = []

        if not os.path.exists(file_path):
            print(f"{Colors.RED}[HATA] {file_path} bulunamadı!")
            return tokens

        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                token = line.strip()
                if token and not token.startswith('#'):
                    # Farklı formatları temizle
                    if ':' in token and len(token.split(':')) >= 2:
                        # email:pass:token formatı
                        parts = token.split(':')
                        token = parts[-1]
                    tokens.append(token.strip('"').strip("'"))

        return list(set(tokens))  # Duplicate'leri temizle

    @staticmethod
    def save_results(filename, data, format='txt'):
        """Sonuçları dosyaya kaydet"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        if format == 'json':
            filename = f"{filename}_{timestamp}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        else:
            filename = f"{filename}_{timestamp}.txt"
            with open(filename, 'w', encoding='utf-8') as f:
                for item in data:
                    f.write(f"{item}\n")

        return filename

    @staticmethod
    def random_user_agent():
        """Rastgele User-Agent oluştur"""
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        ]
        return random.choice(agents)

    @staticmethod
    def format_number(num):
        """Sayıları formatla"""
        if num >= 1_000_000:
            return f"{num/1_000_000:.1f}M"
        elif num >= 1_000:
            return f"{num/1_000:.1f}K"
        return str(num)

    @staticmethod
    def create_folder(folder_name):
        """Klasör oluştur"""
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)