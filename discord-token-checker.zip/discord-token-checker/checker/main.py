import argparse
import sys
import os
from .checker import DiscordTokenChecker
from .utils import Colors, Utils
from .gui import TokenCheckerGUI

def main():
    """Ana fonksiyon"""
    parser = argparse.ArgumentParser(
        description='Discord Token Checker v2.0 - Gelişmiş Token Kontrol Aracı',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Örnek Kullanımlar:
  %(prog)s -f tokens.txt                    # Dosyadan kontrol et
  %(prog)s -f tokens.txt -t 100             # 100 thread ile kontrol et
  %(prog)s -f tokens.txt --gui              # GUI modunda aç
  %(prog)s -f tokens.txt -p proxies.txt     # Proxy kullan
  %(prog)s --single "TOKEN_BURAYA"          # Tek token kontrol et
        """
    )

    parser.add_argument('-f', '--file', 
                       help='Token dosyası yolu',
                       type=str)

    parser.add_argument('-t', '--threads', 
                       help='Thread sayısı (varsayılan: 50)',
                       type=int,
                       default=50)

    parser.add_argument('--timeout', 
                       help='Timeout süresi saniye (varsayılan: 10)',
                       type=int,
                       default=10)

    parser.add_argument('-p', '--proxy', 
                       help='Proxy dosyası',
                       type=str)

    parser.add_argument('--gui', 
                       help='GUI modunda başlat',
                       action='store_true')

    parser.add_argument('--single', 
                       help='Tek token kontrol et',
                       type=str)

    parser.add_argument('-o', '--output', 
                       help='Çıktı klasörü',
                       type=str,
                       default='results')

    parser.add_argument('-v', '--version', 
                       help='Versiyon bilgisi',
                       action='version',
                       version='Discord Token Checker v2.0')

    args = parser.parse_args()

    # GUI modu
    if args.gui:
        gui = TokenCheckerGUI()
        gui.run()
        return

    Utils.clear_screen()
    Utils.print_banner()

    # Tek token kontrolü
    if args.single:
        print(f"{Colors.CYAN}[KONTROL] Tek token kontrol ediliyor...\n")
        checker = DiscordTokenChecker(max_threads=1, timeout=args.timeout)
        result = checker.check_token_details(args.single)

        if result.get('valid'):
            print(f"{Colors.GREEN}✓ GEÇERLİ TOKEN")
            print(f"  Kullanıcı: {result['username']}")
            print(f"  ID: {result['user_id']}")
            print(f"  Email: {result['email']}")
            print(f"  Telefon: {result['phone']}")
            print(f"  Doğrulanmış: {result['verified']}")
            print(f"  2FA: {result['mfa']}")
            print(f"  Nitro: {result['nitro']['type']}")
            print(f"  Oluşturulma: {result['created_at']}")
        else:
            print(f"{Colors.RED}✗ GEÇERSİZ TOKEN - {result.get('error')}")
        return

    # Toplu kontrol
    if not args.file:
        parser.print_help()
        return

    if not os.path.exists(args.file):
        print(f"{Colors.RED}[HATA] {args.file} bulunamadı!")
        return

    # Çıktı klasörünü oluştur
    Utils.create_folder(args.output)
    os.chdir(args.output)

    # Token'ları yükle
    tokens = Utils.load_tokens(args.file)

    if not tokens:
        print(f"{Colors.RED}[HATA] Geçerli token bulunamadı!")
        return

    # Checker'ı oluştur
    checker = DiscordTokenChecker(
        max_threads=args.threads,
        timeout=args.timeout,
        use_proxy=bool(args.proxy),
        proxy_file=args.proxy
    )

    # Kontrolü başlat
    stats = checker.check_tokens_bulk(tokens)

    # Sonuçları kaydet
    print(f"\n{Colors.CYAN}{'='*60}")
    print(f"{Colors.BOLD}SONUÇLAR KAYDEDİLİYOR...{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}\n")

    saved_files = checker.save_all_results()

    for name, filename in saved_files:
        print(f"{Colors.GREEN}✓ {name}: {filename}")

    # Final stats
    print(f"\n{Colors.CYAN}{'='*60}")
    print(f"{Colors.BOLD}FİNAL İSTATİSTİKLER{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}")
    print(f"{Colors.WHITE}Toplam Token: {Colors.BOLD}{stats['total']}")
    print(f"{Colors.GREEN}Geçerli: {Colors.BOLD}{stats['valid']} ({stats['valid_rate']})")
    print(f"{Colors.RED}Geçersiz: {Colors.BOLD}{stats['invalid']}")
    print(f"{Colors.YELLOW}Kilitli: {Colors.BOLD}{stats['locked']}")
    print(f"{Colors.MAGENTA}Nitro: {Colors.BOLD}{stats['nitro']}")
    print(f"{Colors.CYAN}Süre: {Colors.BOLD}{stats['elapsed']:.1f} saniye")
    print(f"{Colors.BLUE}Hız: {Colors.BOLD}{stats['cpm']:.0f} CPM")
    print(f"{Colors.CYAN}{'='*60}")

if __name__ == '__main__':
    main()